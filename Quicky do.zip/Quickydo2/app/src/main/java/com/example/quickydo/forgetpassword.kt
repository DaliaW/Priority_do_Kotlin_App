package com.example.quickydo

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class forgetpassword : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgetpassword)
    }
}
